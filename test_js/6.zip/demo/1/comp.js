Vue.component('mycomp',{
    template: '<h1>Наш первый компонент</h1>'
});