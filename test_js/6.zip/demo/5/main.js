const app = new Vue({
    el: "#app",
    data:{
        name: 'Игорь',
        name2:'Анна'
    }
});