//var mas = [1,2,3,4];
//alert(mas.join(''));
//
//var mas = [1,2,3,4];
//alert(mas.join('-'));
//undefined
//"1, 2, 3, 4".split(', ')
//["1", "2", "3", "4"]

var number = []; // четыре цифры нашего числа
var attempts = 0; // число попыток

generateNumber(); //сгенерировали неповторяющиеся значения массива
alert(number.join(''));//преобразование массива в строку
guessNumber();